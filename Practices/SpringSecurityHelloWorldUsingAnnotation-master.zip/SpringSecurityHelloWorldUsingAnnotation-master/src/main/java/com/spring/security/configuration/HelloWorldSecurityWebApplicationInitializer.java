package com.spring.security.configuration;

import org.springframework.security.web.context.AbstractSecurityWebApplicationInitializer;

/**
 * @author <a href="mailto:psunil1278@gmail.com">Sunil Kumar</a>
 * @since 20/12/15
 */

public class HelloWorldSecurityWebApplicationInitializer extends AbstractSecurityWebApplicationInitializer {

}
